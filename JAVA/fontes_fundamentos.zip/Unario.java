package br.com.rd.quartaturma.fundamentos;

public class Unario {
	public static void main(String[] args) {
		int a = 1;
		int b = 2;
		
		//a--;
		
		++b;
		//--b;
		a = -a;
		System.out.println(a);
		System.out.println(Math.abs(a));
		System.out.println(b);
		
		System.out.println(++a == b--);
//		System.out.println(a == b);
//		System.out.println(a);
//		System.out.println(b);
	}
}
