package br.com.rd.quartaturma.fundamentos;

import java.util.Date;

public class Import {
	public static void main(String[] args) {
		
		String s = "Bom Dia!!";
		
		System.out.println(s);
		
		Date d = new Date();
		
		System.out.println(d);
	}
}
