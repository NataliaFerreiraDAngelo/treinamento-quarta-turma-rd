package br.com.rd.quartaturma.fundamentos;

public class Wrapper {
	public static void main(String[] args) {
		Byte b = 1;
		Short s = 1000;
		Integer i = 10000;
		Long l = 100000L;
		
		System.out.println(b);
		
		Boolean bb = Boolean.parseBoolean("true");
		
		
		
	}
}
