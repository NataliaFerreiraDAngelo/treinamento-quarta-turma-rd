package br.com.rd.quartaturma.fundamentos;

import java.util.Scanner;

public class Console {
	public static void main(String[] args) {
//		System.out.print("Bom\n");
//		System.out.print(" Dia\n");
//		
//		
//		System.out.printf("Megasena %d %d %d %d %d %d", 1,2,3,4,5,6);
	
	Scanner entrada = new Scanner(System.in);
	
	System.out.println("nome.: ");
	String nome = entrada.nextLine();
	
	System.out.println("sobrenome.: ");
	String sobrenome = entrada.nextLine();
	
	System.out.println("idade.: ");
	int idade = entrada.nextInt();

	System.out.println("Nome.: " + nome + " " + sobrenome);
	
	System.out.printf("%s %s tem %d anos.", nome, sobrenome, idade);
	
	entrada.close();
	}
}
