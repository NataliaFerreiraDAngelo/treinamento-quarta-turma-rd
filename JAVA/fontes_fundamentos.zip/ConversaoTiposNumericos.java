package br.com.rd.quartaturma.fundamentos;

public class ConversaoTiposNumericos {
	public static void main(String[] args) {
		float b = (float) 1.23585;
		System.out.println(b);
		
		double a = b;
		
		System.out.println(a);
		

		
		int c = 4;
		byte d = (byte) c;
		System.out.println(d);

		double e = 1.999999999;
		int f = (int) e;
		
		System.out.println(f);
	}
}
