package br.com.rd.quartaturma.fundamentos;

public class Teste {

}
