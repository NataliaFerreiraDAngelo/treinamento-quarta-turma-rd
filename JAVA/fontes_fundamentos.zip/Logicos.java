package br.com.rd.quartaturma.fundamentos;

public class Logicos {
	public static void main(String[] args) {
		boolean condicao = false;
		boolean condicao2 = 3 > 7;
		
		System.out.println(condicao && condicao2);
		System.out.println(condicao || condicao2);
		System.out.println(condicao ^ condicao2);
		System.out.println(!condicao);
		System.out.println(!condicao2);
	}
}
