package br.com.rd.quartaturma.fundamentos;

public class TipoString {
	public static void main(String[] args) {
		
		String nome = "Leo";
		String sobrenome = "Barbosa";
		int idade = 40;
		double salario = 42_356.59;
		char n = 'a';
		
		
//		System.out.println(nome.concat(" " + sobrenome));
		
		String s = "Boa Tarde";
		
		System.out.println(s.startsWith("Boa"));
		System.out.println(s.length());
		System.out.println(s.endsWith("e"));
		
		
	}
}
