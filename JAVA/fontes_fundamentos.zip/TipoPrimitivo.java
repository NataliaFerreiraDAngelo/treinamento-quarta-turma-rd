package br.com.rd.quartaturma.fundamentos;

public class TipoPrimitivo {
	public static void main(String[] args) {
		byte anoDeEmpresa = 23;
		short numeroDeVoos = 542;
		int id = 56789;
		
		long pontoAcumulados = 3_134_845_223L;
		
		
		float salario = 11_445.44F;
		double vendasAcumuladas = 2_991_797_103.01;
		
		//Dias de Empresa
		System.out.println(salario);
		
		
		
		
	}
}
