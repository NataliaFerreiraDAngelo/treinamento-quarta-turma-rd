package br.com.rd.quartaturma.fundamentos;

public class AreaCircunferencia {
	public static void main(String[] args) {
		double raio = 3.4;
		final double pi = 3.14159;
		
		//double area = (raio * raio) * pi;
		
		double area = pi * (Math.pow(raio, 2));
		
		System.out.println("O valor da �rea � igual a.: " + area + " metros quadrados.");
	}
}
