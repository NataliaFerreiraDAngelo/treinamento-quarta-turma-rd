package exercicio1;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Scanner;

public class ListaUsuariosTeste {
	public static void main(String[] args) {

		Map<Long, ArrayList<String>> listaUsuarios = new HashMap<>();
		ArrayList<String> nomes = new ArrayList<>();

		Scanner entrada = new Scanner(System.in);

		System.out.print("Informe a quantidade de listas : ");
		int qtdLista = entrada.nextInt();

		Long codLista;

		try {
			for (int l = 0; l < qtdLista; l++) {
				System.out.print("Informe o identificador da lista: ");
				codLista = entrada.nextLong();

				System.out.print("Informe a quantidade de nomes: ");
				int qtdNomes = entrada.nextInt();

				for (int n = 0; n < qtdNomes; n++) {
					System.out.print("Informe os nomes: ");
					nomes.add(entrada.next());
				}

				listaUsuarios.put(codLista, nomes);

			}

		} catch (Exception e) {

		}

		System.out.println(listaUsuarios);

		

		entrada.close();
	}
}
