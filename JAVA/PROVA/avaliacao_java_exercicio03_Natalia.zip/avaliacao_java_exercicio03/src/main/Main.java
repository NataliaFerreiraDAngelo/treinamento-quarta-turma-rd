package main;

public class Main {

	/**
	 * Rodar esse m�todo para iniciar o jogo.
	 */
	public static void main(String[] args) {
		new JogoDaVelha().iniciar();
	}

}
