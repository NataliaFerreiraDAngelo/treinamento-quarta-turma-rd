package core;

import java.util.Scanner;

import tela.Tela;

public class Jogo {

	/**
	 * Array de Jogada, para marcar as jogadas realizadas.
	 */
	private final Jogada[] JOGADAS = new Jogada[9];
	
	/**
	 * Objeto de Tela, para realizar a comunica��o com o Console.
	 */
	private final Tela TELA;
	
	/**
	 * Objeto de Scanner, para obter comunica��o com o teclado.
	 */
	private final Scanner TECLADO;

	/**
	 * Construtor da classe Jogo.
	 */
	public Jogo() {
		TECLADO = new Scanner(System.in);
		TELA = new Tela();
		JOGADAS[0] = new Jogada(1, 1);
		JOGADAS[1] = new Jogada(1, 2);
		JOGADAS[2] = new Jogada(1, 3);
		JOGADAS[3] = new Jogada(2, 1);
		JOGADAS[4] = new Jogada(2, 2);
		JOGADAS[5] = new Jogada(2, 3);
		JOGADAS[6] = new Jogada(3, 1);
		JOGADAS[7] = new Jogada(3, 2);
		JOGADAS[8] = new Jogada(3, 3);
	}
	
	/**
	 * Destrutor da classe Jogo (para fechar o Scanner quando o objeto for destru�do).
	 */
	public void finalize() {
		TECLADO.close();
	}
	
	public void exibirTela() {
		TELA.exibir(JOGADAS);
	}
	
	public void exibirJogadaInvalida() {
		TELA.exibirJogadaInvalida();
	}
	
	public void exibirJaFoiJogada() {
		TELA.exibirJaFoiJogada();
	}

	public Jogada obterProximaJogada() {
		int linha = obterLinha();		
		int coluna = obterColuna();
		String jogada = obterJogada();
		return new Jogada(linha, coluna, jogada);
	}

	private int obterLinha() {
		int linha;
		do {
			TELA.exibirDigiteLinha(); 
			linha = TECLADO.nextInt();
			if (linha < 1 || linha > 3) {
				TELA.exibirLinhaInvalida();
			}
		} while (linha < 1 || linha > 3);
		return linha;
	}

	private int obterColuna() {
		int coluna;
		do {
			TELA.exibirDigiteColuna();
			coluna = TECLADO.nextInt();
			if (coluna < 1 || coluna > 3) {
				TELA.exibirColunaInvalida();
			}
		} while (coluna < 1 || coluna > 3);
		return coluna;
	}
	
	private String obterJogada() {
		String jogada;
		do {
			TELA.exibirDigiteJogada();
			jogada = TECLADO.next();
			if (!"XxOo".contains(jogada)) {
				TELA.exibirJogadaInvalida();
			}
		} while (!"XxOo".contains(jogada));
		return jogada;
	}
	
	/**
	 * Se a Jogada j� foi realizada anteriormente, retornar true.
	 * Caso contr�rio, false.
	 */
	public boolean jaFoi(Jogada jogada) {
		// TODO: implemente o algoritmo deste m�todo.
		return false;
	}

	/**
	 * Marca Jogada realizada para posterior exibi��o na tela.
	 */
	public void marcaJogada(Jogada jogada) {
		// TODO: implemente o algoritmo deste m�todo.
	}

	/**
	 * Verifica se o jogo j� acabou.
	 * � fim de jogo (deve retornar true) quando: 
	 * - X ou O foi marcado em tr�s posi��es consecutivas, na horizontal, na vertical ou na diagonal; OU
	 * - n�o houver mais jogadas poss�veis para fazer (todas as casas preenchidas). 
	 */
	public boolean acabou() {
		// TODO: implemente o algortimo deste m�todo
		return false;
	}

	public void exibirInicioDeJogo() {
		TELA.exibirInicioDeJogo();
	}
	
	public void exibirFimDeJogo() {
		TELA.exibirFimDeJogo();
	}
	
}
