package Interfaces;

public interface Contrato {
	
	public void emitirContrato();
}
