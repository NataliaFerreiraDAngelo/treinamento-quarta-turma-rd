package Interfaces;

public interface Certidao {
	public void emitirCertidao();
}
