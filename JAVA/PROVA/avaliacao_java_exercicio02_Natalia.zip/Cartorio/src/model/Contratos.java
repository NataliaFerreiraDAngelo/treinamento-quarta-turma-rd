package model;

import Abstratas.Dados;
import Interfaces.Contrato;

public class Contratos extends Dados implements Contrato {
	
	private String nomeComprador;
	private String nomeVendedor;
	private double valor;
	
	public Contratos (String nomeComprador, String nomeVendedor, double valor ) {
		nomeComprador = nomeComprador;
		nomeVendedor = nomeVendedor;
		valor = valor;
	}
	
	
	@Override
	public void emitirContrato() {
		System.out.println("Comprador: " + nomeComprador + "\nVendedor: " + nomeVendedor + "\nValor da negocia��o: " + valor);
		
	}
	
	
}
