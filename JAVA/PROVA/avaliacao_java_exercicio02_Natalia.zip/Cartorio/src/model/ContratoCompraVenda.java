package model;

import Abstratas.Dados;
import Interfaces.Contrato;

public class ContratoCompraVenda extends Dados implements Contrato {

	private String nomeComprador;
	private String nomeVendedor;
	private String nomeBem;
	private double valor;

	public String getNomeBem() {
		return nomeBem;
	}

	public void setNomeBem(String nomeBem) {
		this.nomeBem = nomeBem;
	}

	public String getNomeComprador() {
		return nomeComprador;
	}

	public void setNomeComprador(String nomeComprador) {
		this.nomeComprador = nomeComprador;
	}

	public String getNomeVendedor() {
		return nomeVendedor;
	}

	public void setNomeVendedor(String nomeVendedor) {
		this.nomeVendedor = nomeVendedor;
	}

	public double getValor() {
		return valor;
	}

	public void setValor(double valor) {
		this.valor = valor;
	}

	public ContratoCompraVenda(String nomeComprador, String nomeVendedor, String nomeBem, double valor) {
		nomeComprador = nomeComprador;
		nomeVendedor = nomeVendedor;
		nomeBem = nomeBem;
		valor = valor;
	}

	@Override
	public void emitirContrato() {
		System.out.println("Declaro que o comprador " + getNomeComprador() + " comprou: " + getNomeBem() + " do vendedor: " + getNomeVendedor()
				+ " pelo valor de: " + getValor() + ".");

	}

}
