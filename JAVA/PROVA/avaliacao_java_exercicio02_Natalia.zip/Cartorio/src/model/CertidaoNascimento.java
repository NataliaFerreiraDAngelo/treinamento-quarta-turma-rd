package model;

import Abstratas.Dados;
import Interfaces.Certidao;

public class CertidaoNascimento extends Dados implements Certidao {
	
	private String nomeCertidao;
	
	
	
	public String getNomeCertidao() {
		return nomeCertidao;
	}


	public void setNomeCertidao(String nomeCertidao) {
		this.nomeCertidao = nomeCertidao;
	}


	public CertidaoNascimento (String nomeCertidao) {
		nomeCertidao = nomeCertidao;
	}
	
		
	@Override
	public void emitirCertidao() {
		System.out.println("Declaro o nascimento de: " + getNomeCertidao() + ".");
	}

}
