package model;

import Abstratas.Dados;
import Interfaces.Contrato;

public class ContratoTrabalho extends Dados implements Contrato {

	private String nomeContratante;
	private String nomeTrabalhador;
	private String nomeTrabalho;
	private double valor;

	public String getNomeContratante() {
		return nomeContratante;
	}

	public void setNomeContratante(String nomeContratante) {
		this.nomeContratante = nomeContratante;
	}

	public String getNomeTrabalhador() {
		return nomeTrabalhador;
	}

	public void setNomeTrabalhador(String nomeTrabalhador) {
		this.nomeTrabalhador = nomeTrabalhador;
	}

	public String getNomeTrabalho() {
		return nomeTrabalho;
	}

	public void setNomeTrabalho(String nomeTrabalho) {
		this.nomeTrabalho = nomeTrabalho;
	}

	public double getValor() {
		return valor;
	}

	public void setValor(double valor) {
		this.valor = valor;
	}

	public ContratoTrabalho(String nomeEmpresa, String nomeTrabalhador, String nomeTrabalho, double valor) {
		nomeEmpresa = nomeEmpresa;
		nomeTrabalhador = nomeTrabalhador;
		nomeTrabalho = nomeTrabalho;
		valor = valor;
	}

	@Override
	public void emitirContrato() {
		System.out.println("Declaro que a empresa " + getNomeContratante() + " contratou: " + getNomeTrabalhador()
				+ " para realizar o servi�o de: " + getNomeTrabalho() + " pelo valor de: " + getValor() + ".");

	}

}
