package model;

import Abstratas.Dados;
import Interfaces.Certidao;

public class CertidaoPropriedade extends Dados implements Certidao {

	private String nomeProprietario;
	private String nomeBem;

	public String getNomeProprietario() {
		return nomeProprietario;
	}

	public void setNomeProrpietario(String nomeProrpietario) {
		this.nomeProprietario = nomeProrpietario;
	}

	public String getNomeBem() {
		return nomeBem;
	}

	public void setNomeBem(String nomeBem) {
		this.nomeBem = nomeBem;
	}

	public CertidaoPropriedade(String nomeProrpietario, String nomeBem) {
		nomeProrpietario = nomeProrpietario;
		nomeBem = nomeBem;
	}

	@Override
	public void emitirCertidao() {
		System.out.println("Declaro que o bem : " + getNomeBem() + " pertence �: " + getNomeProprietario());
	}

}
