package model;

import Abstratas.Dados;
import Interfaces.Certidao;

public class CertidaoCasamento extends Dados implements Certidao {

	private String nomeNoivo;
	private String nomeNoiva;

	public String getNomeNoivo() {
		return nomeNoivo;
	}

	public void setNomeNoivo(String nomeNoivo) {
		this.nomeNoivo = nomeNoivo;
	}

	public String getNomeNoiva() {
		return nomeNoiva;
	}

	public void setNomeNoiva(String nomeNoiva) {
		this.nomeNoiva = nomeNoiva;
	}

	public CertidaoCasamento(String nomeNoivo, String nomeNoiva) {
		nomeNoivo = nomeNoivo;
		nomeNoiva = nomeNoiva;
	}

	@Override
	public void emitirCertidao() {
		System.out.println("Declaro o casamento de: " + getNomeNoivo() + " com: " + getNomeNoiva());
	}

}
