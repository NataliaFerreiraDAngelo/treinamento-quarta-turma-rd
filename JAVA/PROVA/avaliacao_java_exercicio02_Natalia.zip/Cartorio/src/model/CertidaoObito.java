package model;

import Abstratas.Dados;
import Interfaces.Certidao;

public class CertidaoObito extends Dados implements Certidao {

	private String nomeCertidao;

	public String getNomeCertidao() {
		return nomeCertidao;
	}

	public void setNomeCertidao(String nomeCertidao) {
		this.nomeCertidao = nomeCertidao;
	}

	public CertidaoObito (String nomeCertidao) {
		nomeCertidao = nomeCertidao;
	}

	@Override
	public void emitirCertidao() {
		System.out.println("Declaro o falecimento de: " + getNomeCertidao());
	}

}
