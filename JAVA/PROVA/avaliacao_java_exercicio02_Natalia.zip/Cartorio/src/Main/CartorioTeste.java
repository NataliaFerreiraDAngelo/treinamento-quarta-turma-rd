package Main;

import java.util.Scanner;

import model.CertidaoCasamento;
import model.CertidaoNascimento;
import model.CertidaoObito;
import model.CertidaoPropriedade;
import model.ContratoCompraVenda;
import model.ContratoTrabalho;
import model.Contratos;

public class CartorioTeste {
	public static void main(String[] args) {
		Scanner entrada = new Scanner(System.in);
		
		System.out.println("Digite o tipo que deseja: 1 - Certid�es 2 - Contrato");
		int opcao = entrada.nextInt();
		
		if (opcao == 1) {
			System.out.println("Digite o tipo de certidao que deseja: \n1 - Nascimento \n2 - Casamento \n3 - �bito \n4 - Propriedade");
			int opcaoCertidao = entrada.nextInt();
			
			if(opcaoCertidao == 1) {
				System.out.println("Digite o nome da crian�a:");
				String nomeCertidao = entrada.next();
				
				CertidaoNascimento cn1 = new CertidaoNascimento (nomeCertidao);
				
				cn1.setNomeCertidao(nomeCertidao);
				
				cn1.emitirCertidao();
				
			}else if(opcaoCertidao == 2) {
				System.out.println("Digite o nome do noivo: ");
				String nomeNoivo = entrada.next();
				
				System.out.println("Digite o nome da noiva: ");
				String nomeNoiva = entrada.next();
				
				CertidaoCasamento cc1 = new CertidaoCasamento (nomeNoivo, nomeNoiva);
				
				cc1.setNomeNoivo(nomeNoivo);
				cc1.setNomeNoiva(nomeNoiva);
				
				cc1.emitirCertidao();
				
			}else if(opcaoCertidao == 3) {
				System.out.println("Digite o nome do falecido: ");
				String nomeCertidao = entrada.next();
				
				CertidaoObito co1 = new CertidaoObito (nomeCertidao);
				
				co1.setNomeCertidao(nomeCertidao);
				
				co1.emitirCertidao();
				
				
			}else if(opcaoCertidao == 4) {
				
				System.out.println("Digite o nome do bem: ");
				String nomeBem = entrada.next();
				
				System.out.println("Digite o nome do propriet�rio(a): ");
				String nomeProprietario = entrada.next();
				
				CertidaoPropriedade cp1 = new CertidaoPropriedade (nomeBem, nomeProprietario);
				
				cp1.setNomeBem(nomeBem);
				cp1.setNomeProrpietario(nomeProprietario);
				
				cp1.emitirCertidao();
				
			}else {
				System.out.println("op��o incorreta");
			}
			
			
		}else if (opcao == 2){
			
			System.out.println("Digite o tipo de contrato que deseja: \n1 - Compra e Venda \n2 - Trabalho ");
			int opcaoContrato = entrada.nextInt();
			
			if (opcaoContrato == 1) {
				System.out.println("Digite o nome do comprador:");
				String comprador = entrada.next();
				
				System.out.println("Digite o nome do vendedor:");
				String vendedor = entrada.next();
				
				System.out.println("Digite o bem negociado:");
				String bem = entrada.next();
				
				System.out.println("Digite o valor da negocia��o:");
				double valor = entrada.nextDouble();
				
				ContratoCompraVenda ccv1 = new ContratoCompraVenda(comprador, vendedor, bem, valor);
				
				ccv1.setNomeComprador(comprador);
				ccv1.setNomeVendedor(vendedor);
				ccv1.setValor(valor);
				ccv1.setNomeBem(bem);
				
				ccv1.emitirContrato();
				
			}else if(opcaoContrato == 2) {
				System.out.println("Digite o nome do contratante:");
				String contratante = entrada.next();
				
				System.out.println("Digite o nome do trabalhador:");
				String trabalhador = entrada.next();
				
				System.out.println("Digite o servi�o:");
				String servico = entrada.next();
				
				System.out.println("Digite o valor:");
				double valor = entrada.nextDouble();
				
				ContratoTrabalho ct1 = new ContratoTrabalho(contratante, trabalhador, servico, valor);
				
				ct1.setNomeContratante(contratante);
				ct1.setNomeTrabalhador(trabalhador);
				ct1.setNomeTrabalho(servico);
				ct1.setValor(valor);
				
				ct1.emitirContrato();
				
			}else {
				System.out.println("op��o incorreta");
			}
			
			
			
			
			
		}else {
			System.out.println("op��o incorreta");
		}

		entrada.close();
		
	}
}
