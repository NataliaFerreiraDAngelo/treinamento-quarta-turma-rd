package Abstratas;

public abstract class Dados {
	
	public void Contrato() {
		
	}
	
}
