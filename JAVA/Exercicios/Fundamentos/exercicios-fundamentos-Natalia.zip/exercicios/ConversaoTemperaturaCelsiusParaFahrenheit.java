package br.com.rd.exercicios;

import java.util.Scanner;

public class ConversaoTemperaturaCelsiusParaFahrenheit {
	public static void main(String[] args) {
		
		Scanner temperatura = new Scanner(System.in);
		
		System.out.print("Informe a temperatura em Celsius: ");
        double celsius = temperatura.nextDouble();
       
        
        
        double resultado = (celsius * 9 / 5) + 32;
        
        
        System.out.print("A temperatura de " + celsius + " Celsius � equivalent � " + resultado + " Fahrenheit.");
        
        temperatura.close();
        
	}
}
