package br.com.rd.exercicios;

import java.util.Scanner;

public class ConversaoTemperaturaFahrenheitParaCelsius {
	public static void main(String[] args) {

		Scanner temperatura = new Scanner(System.in);

		System.out.print("Informe a temperatura em Fahrenheit: ");
		double fahrenheit = temperatura.nextDouble();

		double resultado = (fahrenheit - 32) * 5 / 9;

		System.out.print("A temperatura de " + fahrenheit + " Fahrenheit � equivalent � " + resultado + " Celsius.");

		temperatura.close();

	}

}
