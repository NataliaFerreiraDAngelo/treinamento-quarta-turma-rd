package br.com.rd.exercicios;

import java.util.Scanner;

public class CalculadoraSimples {
	public static void main(String[] args) {
		Scanner numero = new Scanner(System.in);

		System.out.print("Informe o primeiro n�mero: ");
		double num1 = numero.nextDouble();

		System.out.print("Informe o segundo n�mero: ");
		double num2 = numero.nextDouble();

		System.out.print(
				"Informe a opera��o desejada: \n 1 - Adi��o \n 2 - Subtra��o \n 3 - Multiplica��o \n 4 - Divis�o \n 5 - Resto da Divis�o \n");
		int operacao = numero.nextInt();

		double soma = num1 + num2;

		double subtracao = num1 - num2;

		double multiplicacao = num1 * num2;

		double divisao = num1 / num2;

		double resto = num1 % num2;

		double resultado = (operacao == 1) ? soma : 
						   (operacao == 2) ? subtracao : 
						   (operacao == 3) ? multiplicacao : 
						   (operacao == 4) ? divisao : resto;

		System.out.print("o resultado da opera��o dos n�meros " + num1 + " e " + num2 + " � de: " + resultado + " .");

		numero.close();
	}
}
