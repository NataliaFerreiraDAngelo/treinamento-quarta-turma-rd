package br.com.rd.exercicios;

import java.util.Scanner;

public class ResultadoAoQuadradoEAoCubo {
	public static void main(String[] args) {

		Scanner numero = new Scanner(System.in);

		System.out.print("Informe um n�mero: ");
		double numeroInformado = numero.nextDouble();

		double quadrado = Math.pow(numeroInformado, 2);
		
		double cubo = Math.pow(numeroInformado, 3);

		System.out.print("O n�mero " + numeroInformado + " elevado ao quadrado � " + quadrado + " e elevado ao cubo � " + cubo + " .");

		numero.close();

	}
}
