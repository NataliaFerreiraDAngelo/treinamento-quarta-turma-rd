package br.com.rd.exercicios;

public class CalculoParaEncontrarODelta {
	public static void main(String[] args) {

		int a = 1;
		int b = 12;
		int c = -13;

		double delta = (Math.pow(b, 2) - (4 * a * c));

		String resultado1 = (a <= 0) ? "O valor de A � menor ou igual a 0." : "O valor de Delta �: " + delta + ".";

		System.out.println(resultado1);

		double x1 = (-b + Math.sqrt(delta)) / (2 * a);

		double x2 = (-b - Math.sqrt(delta)) / (2 * a);

		String resultado2 = (delta < 0 || a <= 0)
				? "N�o � poss�vel calcular o valor de x1 e x2. Ou o valor do A � igual ou menor do que 0 ou o valor de Delta � negativo."
				: "O valor de x1 �: " + x1 + "e o valor de x2 �: " + x2 + ".";

		System.out.println(resultado2);

	}
}
