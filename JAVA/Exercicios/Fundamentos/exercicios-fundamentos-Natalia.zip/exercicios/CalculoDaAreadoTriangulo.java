package br.com.rd.exercicios;

import java.util.Scanner;

public class CalculoDaAreadoTriangulo {
	public static void main(String[] args) {

		Scanner numero = new Scanner(System.in);

		System.out.print("Informe o tamanho da base do tri�ngulo: ");
		double base = numero.nextDouble();
		
		System.out.print("Informe o tamanho da altura do tri�ngulo: ");
		double altura = numero.nextDouble();

		double area = (base * altura ) /2;

		System.out.print("A �rea do triangulo de base " + base + " e altura " + altura + " � de: " + area + " .");

		numero.close();

	}
}
