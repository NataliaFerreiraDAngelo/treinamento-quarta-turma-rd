package br.com.rd.exercicios;

import java.util.Scanner;

public class CalculaIMC {

	public static void main(String[] args) {

		Scanner numero = new Scanner(System.in);

		System.out.print("Informe a altura: ");
		double altura = numero.nextDouble();
		
		System.out.print("Informe o peso: ");
		double peso = numero.nextDouble();

		double resultado = peso / (Math.pow(altura, 2));

		System.out.print("O IMC � " + resultado + ", de acordo com o peso de " + peso + " kg e a altura de " + altura + " cm.");

		numero.close();

	}
}
