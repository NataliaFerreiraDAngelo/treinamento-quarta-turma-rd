package br.com.rd.exercicio;

public class Ferrari extends Carro {
	Ferrari(int x) {
		super(x);
	}

	int acelerar() {
		if ( (velocidadeAtual  + 15) > velocidadeMaxima) {
			velocidadeAtual = velocidadeMaxima;
			return velocidadeAtual;
		} else if (velocidadeAtual <= (velocidadeMaxima - 15)) {
			velocidadeAtual += 15;
			return velocidadeAtual;
		} else {
			return velocidadeMaxima;
		}
	}
}
