package br.com.rd.exercicio;

import java.util.Scanner;

public class CarroTeste {
	public static void main(String[] args) {

		Scanner entrada = new Scanner(System.in);
		System.out.print("Qual carro voc� deseja criar? (1 - Civic ou 2 - Ferrari): ");
		int tipoCarro = entrada.nextInt();
		
		if (tipoCarro == 1) {
			System.out.print("Informe a velocidade m�xima que deseja para este carro:");
			int velocidadeMaxima = entrada.nextInt();

			Civic c1 = new Civic(velocidadeMaxima);

			System.out.print("O que voc� deseja fazer com o carro? (1 - Acelerar, 2 - Frear ou 3 - Finalizar) ");
			int opcaoCarro = entrada.nextInt();

			while (opcaoCarro != 3) {
				if (opcaoCarro == 1) {
					c1.acelerar();
					System.out.println("A velocidade atual �: " + c1.velocidadeAtual + " km/h.");

				} else if (opcaoCarro == 2) {
					c1.frear();
					System.out.println("A velocidade atual �: " + c1.velocidadeAtual + " km/h.");

				} else {
					System.out.println("Comando inv�lido.");

				}

				System.out
						.print("O que voc� deseja fazer com o carro? (1 - Acelerar, 2 - Frear ou 3 - Finalizar) ");
				opcaoCarro = entrada.nextInt();
			}

		} else if (tipoCarro == 2) {

			System.out.print("Informe a velocidade m�xima que deseja para este carro:");
			int velocidadeMaxima = entrada.nextInt();

			Ferrari c2 = new Ferrari(velocidadeMaxima);

			System.out.print("O que voc� deseja fazer com o carro? (1 - Acelerar, 2 - Frear ou 3 - Finalizar) ");
			int opcaoCarro = entrada.nextInt();

			while (opcaoCarro != 3) {
				if (opcaoCarro == 1) {
					c2.acelerar();
					System.out.println("A velocidade atual �: " + c2.velocidadeAtual + " km/h.");

				} else if (opcaoCarro == 2) {
					c2.frear();
					System.out.println("A velocidade atual �: " + c2.velocidadeAtual + " km/h.");

				} else {
					System.out.println("Comando inv�lido.");

				}

				System.out
						.print("O que voc� deseja fazer com o carro? (1 - Acelerar, 2 - Frear ou 3 - Finalizar) ");
				opcaoCarro = entrada.nextInt();
			}

		} else {
			System.out.println("Comando inv�lido.");
		}

		entrada.close();
	}
}
