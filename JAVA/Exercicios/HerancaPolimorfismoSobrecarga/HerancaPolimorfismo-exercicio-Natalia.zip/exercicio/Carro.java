package br.com.rd.exercicio;

public class Carro {
	int velocidadeMaxima;
	int velocidadeAtual = 0;

	Carro(int x) {
		velocidadeMaxima = x;
	}

	public int getVelocidadeAtual() {
		return velocidadeAtual;
	}

	int acelerar() {
		if ( (velocidadeAtual  + 5) > velocidadeMaxima) {
			velocidadeAtual = velocidadeMaxima;
			return velocidadeAtual;
		} else if (velocidadeAtual <= (velocidadeMaxima - 5)) {
			velocidadeAtual += 5;
			return velocidadeAtual;
		}else {
			return velocidadeMaxima;
		}

	}

	int frear() {
		if (velocidadeAtual >= 5) {
			velocidadeAtual -= 5;
			return velocidadeAtual;
		}else {
			velocidadeAtual = 0;
			return velocidadeAtual;
		}
	}

}
