package br.com.rd.exercicio;

public class Civic extends Carro {
	Civic(int x) {
		super(x);
	}
}
