package br.com.rd.estruturas;

import java.util.Scanner;

public class TesteMultiplos {
	public static void main(String[] args) {

		Scanner numero = new Scanner(System.in);

		System.out.print("Informe o primeiro n�mero: ");
		int num1 = numero.nextInt();

		System.out.print("Informe o segundo n�mero: ");
		int num2 = numero.nextInt();

		int maior = 0;
		int menor = 0;

		if (num1 >= num2) {
			maior = num1;
			menor = num2;
		} else {
			maior = num2;
			menor = num1;
		}

		if (maior % menor == 0) {
			System.out.print("Os n�meros " + menor + " e " + maior + " s�o m�ltiplos.");
		} else {
			System.out.print("Os n�meros " + menor + " e " + maior + " n�o s�o m�ltiplos.");
		}

		numero.close();
	}
}
