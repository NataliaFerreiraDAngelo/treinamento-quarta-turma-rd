package br.com.rd.estruturas;

import java.util.Scanner;

public class VerificacaoIntevalo {
	public static void main(String[] args) {

		Scanner numero = new Scanner(System.in);

		System.out.print("Informe um n�mero inteiro: ");
		int num = numero.nextInt();

		if (num >=0 && num < 25) {
			System.out.print("O n�mero " + num + " est� no intervalo entre 0 e 25.");
		} else if (num >=25 && num < 50) {
			System.out.print("O n�mero " + num + " est� no intervalo entre 25 e 50.");
		} else if (num >=50 && num < 75) {
			System.out.print("O n�mero " + num + " est� no intervalo entre 50 e 75.");
		} else if (num >=75 && num < 100) {
			System.out.print("O n�mero " + num + " est� no intervalo entre 75 e 100.");
		} else {
			System.out.print("Fora de intervalo.");
		}

		numero.close();
	}
}
