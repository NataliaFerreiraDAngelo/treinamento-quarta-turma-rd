package br.com.rd.estruturas;

import java.util.Scanner;

public class TesteValorNegativo {

	public static void main(String[] args) {
		
		Scanner numero = new Scanner(System.in);

		System.out.print("Informe um n�mero inteiro: ");
		int num = numero.nextInt();

		if(num >= 0) {
			System.out.print("O n�mero " + num + " � positivo");
		}else {
			System.out.print("O n�mero " + num + " � negativo");
		}

		
		numero.close();
	}
}
