package br.com.rd.estruturas;

import java.util.Scanner;

public class TesteParOuImpar {
	public static void main(String[] args) {

		Scanner numero = new Scanner(System.in);

		System.out.print("Informe um n�mero inteiro: ");
		int num = numero.nextInt();

		if (num % 2 == 0) {
			System.out.print("O n�mero " + num + " � par");
		} else {
			System.out.print("O n�mero " + num + " � �mpar");
		}

		numero.close();
	}
}
