package br.com.rd.estruturas;

import java.util.Scanner;

public class CalculoDuracaoJogo {

	public static void main(String[] args) {

		Scanner numero = new Scanner(System.in);

		System.out.print("Informe a hora inicial: ");
		int horaInicial = numero.nextInt();

		System.out.print("Informe a hora final: ");
		int horaFinal = numero.nextInt();

		int duracao = 0;
		
		if (horaFinal >  horaInicial) {
			duracao = horaFinal - horaInicial;
		} else {
			duracao = horaFinal - horaInicial + 24;
		}

		System.out.print("A dura��o do jogo foi  " + duracao + " horas.");
		
		
		numero.close();
	}

}
