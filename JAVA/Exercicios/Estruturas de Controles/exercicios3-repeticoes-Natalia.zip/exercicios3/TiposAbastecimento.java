package br.com.rd.exercicios3;

import java.util.Scanner;

public class TiposAbastecimento {
	public static void main(String[] args) {

		Scanner numero = new Scanner(System.in);
		System.out.println("Informe o tipo de combust�vel abastecido: 1.�lcool 2.Gasolina 3.Diesel 4.Fim ");
		int opcao = numero.nextInt();
		
		int alcool = 0;
		int gasolina = 0;
		int diesel = 0;
		
		while (opcao != 4) {
			
			if (opcao == 1) {
				alcool +=1;
			} else if (opcao == 2) {
				gasolina +=1;
			} else if (opcao == 3) {
				diesel +=1;
			}
			
			System.out.println("Informe o tipo de combust�vel abastecido: 1.�lcool  2.Gasolina 3.Diesel 4.Fim ");
			opcao = numero.nextInt();
			
			
		}
			

		System.out.print("MUITO OBRIGADO \nAlcool: " + alcool + "\nGasolina: " + gasolina + "\nDiesel: " + diesel);

		numero.close();
	}
}
