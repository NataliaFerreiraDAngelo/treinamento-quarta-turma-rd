package br.com.rd.exercicios3;

import java.util.Scanner;

public class NumerosDentroDoIntervalo {
	public static void main(String[] args) {

		Scanner numero = new Scanner(System.in);
		System.out.println("Informe a quantidade de n�meros que dever� ser considerada:");
		int quantidade = numero.nextInt();
		
		int in = 0;
		int out = 0;
		
		for (int i = 1 ; i <= quantidade; i++) {
			System.out.println("Informe o n�mero " + i + ":");
			int num = numero.nextInt();
			
			if (num >= 10 && num <=20) {
				in ++;
			} else {
				out ++;
			}
			
		}


		System.out.print(in + " in \n" + out + " out");

		numero.close();
	}
}
