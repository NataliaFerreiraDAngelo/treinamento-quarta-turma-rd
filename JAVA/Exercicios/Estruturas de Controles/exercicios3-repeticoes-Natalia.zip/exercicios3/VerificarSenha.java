package br.com.rd.exercicios3;

import java.util.Scanner;

public class VerificarSenha {
	public static void main(String[] args) {

		Scanner numero = new Scanner(System.in);
		System.out.print("Informe a senha: ");
		int senha = numero.nextInt();
		
		while (senha != 2002) {
			System.out.print("Senha Invalida. Informe a senha: ");
			senha = numero.nextInt();			
		} ; 
		
		
		System.out.print("Acesso Permitido");
		
			
		

		numero.close();
		}
	
}
