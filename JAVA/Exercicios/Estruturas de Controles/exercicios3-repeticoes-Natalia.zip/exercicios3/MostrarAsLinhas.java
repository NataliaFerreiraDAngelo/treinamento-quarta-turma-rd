package br.com.rd.exercicios3;

import java.util.Scanner;

public class MostrarAsLinhas {
	public static void main(String[] args) {

		Scanner numero = new Scanner(System.in);
		System.out.println("Informe a quantidade de linhas que dever� ser considerada:");
		int quantidade = numero.nextInt();

		int quadrado = 0;
		int cubo = 0;
		
		System.out.print(quantidade + "\n");
		
		for (int i = 1; i <= quantidade; i++) {
			quadrado = (int) Math.pow(i, 2);
			System.out.print(quadrado + " ");

			cubo = (int) Math.pow(i, 3);
			System.out.print(cubo + "\n");
		}

		numero.close();
	}
}
