package br.com.rd.quartaturma.main;

import java.util.Scanner;

import br.com.rd.quartaturma.util.Salario;

public class Calculos {
	public static void main(String[] args) {

		Scanner entrada = new Scanner(System.in);

		Salario calculosSalario = new Salario();

		System.out.print("Informe o nome do funcion�rio: ");
		String nome = entrada.next();

		System.out.print("Informe o sal�rio bruto: ");
		double salariobruto = entrada.nextDouble();

		System.out.print("Informe o percentual do imposto: ");
		double imposto = entrada.nextDouble();

		double salarioLiquido = calculosSalario.calcularSalarioLiquido(salariobruto, imposto);

		System.out.println("Dados do funcion�rio: \nNome: " + nome + "\nO sal�rio l�quido � de : " + salarioLiquido);

		System.out.print("Informe o percentual do aumento: ");
		double aumento = entrada.nextDouble();

		double salarioNovo = calculosSalario.calcularAumento(salariobruto, aumento);
		
		double novoSalarioLiquido = calculosSalario.calcularSalarioLiquido(salarioNovo, imposto);

		System.out.println("Dados do funcion�rio: \nNome: " + nome + "\nO sal�rio bruto com o aumento � de : "
				+ salarioNovo + "\nO sal�rio l�quido com o aumento � de : " + novoSalarioLiquido);

		entrada.close();
	}

}
