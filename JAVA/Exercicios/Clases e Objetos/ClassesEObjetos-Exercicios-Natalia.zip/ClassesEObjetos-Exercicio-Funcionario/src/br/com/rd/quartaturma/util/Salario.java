package br.com.rd.quartaturma.util;


public class Salario {
	
	public double salarioBruto = 0;
	public double impostos = 0;
	public double salarioLiquido = 0;
	public double aumento = 0;
	public double novoSalario = 0;

	public double calcularSalarioLiquido(double salarioBruto, double impostos) {

		salarioLiquido = salarioBruto - (salarioBruto * (impostos/100));

		return salarioLiquido;
	}

	public double calcularAumento(double salarioBruto, double aumento) {

		novoSalario = salarioBruto +  (salarioBruto * (aumento/100));

		return novoSalario;
	}

	
}
