package br.com.rd.quartaturma.main;

import java.util.Scanner;
import br.com.rd.quartaturma.util.Retangulos;

public class Calculos {

	public static void main(String[] args) {

		Scanner entrada = new Scanner(System.in);

		Retangulos retangulo = new Retangulos();

		System.out.println("Base: ");
		double base = entrada.nextDouble();

		System.out.println("Altura");
		double altura = entrada.nextDouble();

		double area = retangulo.calcularArea(base, altura);

		double perimetro = retangulo.calcularPerimetro(base, altura);

		double diagonal = retangulo.calcularDiagonal(base, altura);

		System.out.println("A �rea do ret�ngulo �: " + area + "\nO per�metro do ret�ngulo �: " + perimetro
				+ "\nA Diagonal do ret�ngulo �: " + diagonal);

		entrada.close();
	}

}
