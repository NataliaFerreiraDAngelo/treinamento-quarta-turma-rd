package br.com.rd.quartaturma.util;

public class Retangulos {

	public double area = 0;
	public double perimetro = 0;
	public double diagonal = 0;

	public double calcularArea(double base, double altura) {

		area = base * altura;

		return area;
	}

	public double calcularPerimetro(double base, double altura) {

		perimetro = (base + altura) * 2;

		return perimetro;
	}

	public double calcularDiagonal(double base, double altura) {

		diagonal = Math.sqrt((Math.pow(base, 2))+(Math.pow(altura, 2)));

		return diagonal;
	}

}
