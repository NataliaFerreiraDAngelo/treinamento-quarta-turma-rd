package br.com.rd.quartaturma.util;

public class NotasAluno {
	
	public double nota1 = 0;
	public double nota2 = 0;
	public double nota3 = 0;
	public double media = 0;

	public double calcularMedia(double nota1, double nota2, double nota3) {

		media = ((nota1 * 30) + (nota2 * 35) + (nota3 * 35))/100;

		return media;
	}
}
