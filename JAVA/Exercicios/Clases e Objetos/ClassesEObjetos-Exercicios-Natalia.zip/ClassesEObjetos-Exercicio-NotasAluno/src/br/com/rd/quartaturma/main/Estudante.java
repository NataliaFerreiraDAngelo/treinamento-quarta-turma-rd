package br.com.rd.quartaturma.main;

import java.util.Scanner;

import br.com.rd.quartaturma.util.NotasAluno;

public class Estudante {

	public static void main(String[] args) {

		Scanner entrada = new Scanner(System.in);

		NotasAluno calculoNotas = new NotasAluno();

		System.out.print("Informe o nome do aluno: ");
		String nome = entrada.next();

		System.out.print("Informe a primeira nota: ");
		double nota1 = entrada.nextDouble();
		
		System.out.print("Informe a segunda nota: ");
		double nota2 = entrada.nextDouble();
		
		System.out.print("Informe a terceira nota: ");
		double nota3 = entrada.nextDouble();

		double media = calculoNotas.calcularMedia(nota1, nota2, nota3);
		
		String resultado = "";
		double pontosFaltantes = 0;
		
		if (media < 6) {
			pontosFaltantes = 6 - media ;
		}
		
		if (media >= 6) {
			resultado = "PASS";
		} else {
			resultado = ("FAILED, faltam " + pontosFaltantes + " para atingir a m�dia m�nima");
		}
		
		
		System.out.println("Dados do Aluno: \nNome: " + nome + "\nM�dia: " + media + "\nSitua��o: " + resultado);


		entrada.close();
	}

}
