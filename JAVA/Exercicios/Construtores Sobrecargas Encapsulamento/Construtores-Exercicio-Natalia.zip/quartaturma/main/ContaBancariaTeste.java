package br.com.rd.quartaturma.main;

import java.util.Scanner;

import br.com.rd.quartaturma.util.ContaBancariaDados;
import br.com.rd.quartaturma.util.MovimentacaoConta;

public class ContaBancariaTeste {
	public static void main(String[] args) {

		Scanner entrada = new Scanner(System.in);
		
		System.out.print("Titular da Conta: ");
		String nome = entrada.nextLine();
		
		System.out.print("N�mero da Conta: ");
		int conta = entrada.nextInt();

		ContaBancariaDados cc1 = new ContaBancariaDados(nome, conta);

		System.out.print("Ser� feito o dep�sito inicial(s � sim / n � n�o)? ");
		String opcaoDeposito = entrada.next();

		MovimentacaoConta movimentaConta = new MovimentacaoConta();

		if (opcaoDeposito.equals("s")) {
			System.out.print("Dep�sito Inicial: ");
			double depositoInicial = entrada.nextDouble();

			double saldoAtualizado = movimentaConta.fazerDepositoInicial(depositoInicial);

			System.out.print("Dados da Conta: \nConta N�mero " + cc1.getConta() + ", Titular " + cc1.getNome()
					+ ", Saldo $ " + saldoAtualizado);
		} else {
			System.out.print("Dados da Conta: \nConta N�mero " + cc1.getConta() + ", Titular " + cc1.getNome()
					+ ", Saldo $ " + movimentaConta.getSaldoAtualizado());
		}

		System.out.print("\nDeseja realizar outra opera��o(s � sim / n � n�o)? ");
		String opcaoOperacao = entrada.next();

		while (opcaoOperacao.equals("s")) {
			System.out.print("Qual opera��o (1 � dep�sito / 2 � saque)? ");
			int opcao = entrada.nextInt();

			if (opcao == 1) {
				System.out.print("Informe o valor do dep�sito: ");
				double deposito = entrada.nextDouble();

				movimentaConta.fazerDeposito(deposito);

				System.out.print("Dados da Conta: \nConta N�mero " + cc1.getConta() + ", Titular " + cc1.getNome()
						+ ", Saldo $ " + movimentaConta.getSaldoAtualizado());
			} else {
				System.out.print("Informe o valor do saque: ");
				double saque = entrada.nextDouble();

				movimentaConta.fazerRetirada(saque);

				System.out.print("Dados da Conta: \nConta N�mero " + cc1.getConta() + ", Titular " + cc1.getNome()
						+ ", Saldo $ " + movimentaConta.getSaldoAtualizado());
			}
			
			System.out.print("\nDeseja realizar outra opera��o(s � sim / n � n�o)? ");
			opcaoOperacao = entrada.next();
		}
		

		System.out.print("Dados da Conta: \nConta N�mero " + cc1.getConta() + ", Titular " + cc1.getNome()
				+ ", Saldo $ " + movimentaConta.getSaldoAtualizado());

		entrada.close();
	}
}
