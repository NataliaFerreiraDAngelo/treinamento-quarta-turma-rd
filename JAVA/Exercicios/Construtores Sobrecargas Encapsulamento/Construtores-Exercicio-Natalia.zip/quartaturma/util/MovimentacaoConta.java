package br.com.rd.quartaturma.util;

public class MovimentacaoConta {

	private double saldoInicial = 0;
	private double deposito;
	private double saque;
	private double saldoAtualizado;

	public double getDeposito() {
		return deposito;
	}

	public void setDeposito(double deposito) {
		this.deposito = deposito;
	}

	public double getSaque() {
		return saque;
	}

	public void setSaque(double saque) {
		this.saque = saque;
	}

	public double getSaldoInicial() {
		return saldoInicial;
	}

	public double getSaldoAtualizado() {
		return saldoAtualizado;
	}

	public double fazerDepositoInicial(double deposito) {

		saldoAtualizado = saldoInicial + deposito;

		return saldoAtualizado;
	};

	public double fazerDeposito(double valorDeposito) {

		saldoAtualizado += valorDeposito;

		return saldoAtualizado;
	};

	public double fazerRetirada(double valorRetirada) {

		saldoAtualizado -= (valorRetirada + 5);

		return saldoAtualizado;
	};

}
