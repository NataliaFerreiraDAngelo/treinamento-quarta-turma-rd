package br.com.rd.quartaturma.util;

public class ContaBancariaDados {

	private String nome;
	private long conta;
	
	public ContaBancariaDados(String nomeInicial, long contaInicial) {
		nome = nomeInicial;
		conta = contaInicial;
	};

	public String getNome() {
		return nome;
	};

	public void setNome(String nome) {
		this.nome = nome;
	};

	public long getConta() {
		return conta;
	}

	
}
