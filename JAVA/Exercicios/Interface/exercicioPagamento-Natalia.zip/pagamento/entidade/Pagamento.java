package com.pagamento.entidade;

import java.util.ArrayList;

import com.pagamento.servicos.Pagamentos;

public class Pagamento implements Pagamentos{
	
	private Double valorTotal;
	private int qtdeParcelas;
	private double parcelaComJuros;
	private double parcelaTotal;
	private double parcelaInicial;
	ArrayList<Double> listaPagamentos = new ArrayList<>();
	
	public Pagamento(Double valorTotal, int qtdeParcelas) {
		parcelaInicial = valorTotal / qtdeParcelas;
		
		for (int p = 1; p <= qtdeParcelas; p++) {
			parcelaComJuros = parcelaInicial + (parcelaInicial * (0.01 * p));
			parcelaTotal = parcelaComJuros * 1.02;
			listaPagamentos.add(parcelaTotal);
		}
	}
	
	
	@Override
	public void calcularPagamentos() {
		System.out.println(listaPagamentos);
		
	}
}
