package com.pagamento.entidade;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

import com.pagamento.servicos.Contratos;

public class Contrato implements Contratos {
	private int qtdeParcelas;
	private String dataInicio;
	ArrayList<String> listaDatas = new ArrayList<>();
	private String dataVencimento;
	
	
	
	
	public Contrato(String dataInicio, int qtdeParcelas ) {
		
		DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate data = LocalDate.parse(dataInicio, formato);
		
		for (int d = 1; d <= qtdeParcelas; d++) {
			data = data.plusDays(30);
			
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");

	        String dataVencimento = data.format(formatter);
			 
						
			listaDatas.add(dataVencimento);
		}
	}
	
	
	
	@Override
	public void calcularDatas() {
		System.out.println(listaDatas);
		
	}

}
