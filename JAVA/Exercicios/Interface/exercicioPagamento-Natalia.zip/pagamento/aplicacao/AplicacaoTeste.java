package com.pagamento.aplicacao;

import java.util.Scanner;

import com.pagamento.entidade.Contrato;
import com.pagamento.entidade.Pagamento;

public class AplicacaoTeste {
	public static void main(String[] args) {
	
		Scanner entrada = new Scanner(System.in);
		
		System.out.println("Forne�a os Dados do Contrato ");

		System.out.print("Numero:  ");
		long contrato = entrada.nextLong();
		
		entrada = new Scanner(System.in);

		System.out.print("Data (dd/MM/yyyy): ");
		String dataInicio = entrada.nextLine();
		
		System.out.print("Valor:  ");
		double valorTotal = entrada.nextDouble();

		System.out.print("Numero de Parcelas:  ");
		int qtdeParcelas = entrada.nextInt();
		
		Pagamento pgtos = new Pagamento(valorTotal, qtdeParcelas);
		
		Contrato cont = new Contrato (dataInicio, qtdeParcelas);
		
		cont.calcularDatas();
		pgtos.calcularPagamentos();
	
		
		entrada.close();
		
		
	}
}
