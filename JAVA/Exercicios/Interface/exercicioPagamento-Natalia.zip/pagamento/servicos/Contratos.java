package com.pagamento.servicos;

public interface Contratos {
	
	public void calcularDatas();
	
}
