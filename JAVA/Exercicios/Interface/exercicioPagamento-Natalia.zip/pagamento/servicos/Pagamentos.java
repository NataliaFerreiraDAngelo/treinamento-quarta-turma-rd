package com.pagamento.servicos;

public interface Pagamentos {
	
	public void calcularPagamentos();
	
}
