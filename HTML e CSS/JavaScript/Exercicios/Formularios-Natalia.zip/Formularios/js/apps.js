let nome = document.getElementById("input-nome");
let cpf = document.getElementById("input-cpf");
let endereco = document.getElementById("input-endereco");
let bairro = document.getElementById("input-bairro");
let cep = document.getElementById("input-cep");
let regexCpf = /^([0-9]{3}\.?[0-9]{3}\.?[0-9]{3}\-?[0-9]{2}|[0-9]{2}\.?[0-9]{3}\.?[0-9]{3}\/?[0-9]{4}\-?[0-9]{2})$/;
let regexCep = /[0-9]{2}\.?[0-9]{3}\-?[\d]{3}/;


nome.onblur = function() {
    let valor = nome.value
    if (valor.length == 0) {
        document.querySelector(".alert-nome").style.display = "block"
        return;
    }
    document.querySelector(".alert-nome").style.display = "none"
}

cpf.onblur = function() {
    if (!regexCpf.test(this.value)) {
        document.querySelector(".alert-cpf").style.display = "block";
        return;
    }
    document.querySelector(".alert-cpf").style.display = "none";
};

endereco.onblur = function() {
    let valor = endereco.value;
    if (valor.length == 0) {
        document.querySelector(".alert-endereco").style.display = "block";
        return;
    }
    document.querySelector(".alert-endereco").style.display = "none";
};

bairro.onblur = function() {
    let valor = bairro.value;
    if (valor.length == 0) {
        document.querySelector(".alert-bairro").style.display = "block";
        return;
    }
    document.querySelector(".alert-bairro").style.display = "none";
};

cep.onblur = function(){
    if (!regexCep.test(this.value)) {
        document.querySelector(".alert-cep").style.display = "block";
        return;
    }
    document.querySelector(".alert-cep").style.display = "none";
};

$(cep).ready(function(){
    $('.cep').mask('00.000-000');
});